CREATE OR REPLACE VIEW transportation.gold.fact_trips_visakhapatnam
AS (
SELECT *
FROM transportation.gold.fact_trips
WHERE city_id = 'AP01'
);